package stepdef;

import apiEngine.EndPoints;
import io.cucumber.java.en.*;

public class step {


	EndPoints endpoint;
	EndPoints endpoint1;
	@Given("Verify user should able to access the Base-URL {string}")
	public void verify_user_should_able_to_access_the_base_url(String baseURL) {
		
		endpoint = new EndPoints("khjh");
		
	}
	@Given("Verify user should not able to access the Base-URL {string}")
	public void verify_user_should_not_able_to_access_the_base_url(String baseURL) {
		
		
		endpoint1 = new EndPoints(baseURL);
	}
	@When("Verify user should able to access Post {string} Method")
	public void verify_user_should_able_to_access_post_method(String string) {
		
		
		
	}
	@When("Verify user should not be able to access Add place request with invalid HTTP {string} Method")
	public void verify_user_should_not_be_able_to_access_add_place_request_with_invalid_http_method(String string) {
		
		
		
	}
	@Given("Verify user should able to accept the payload")
	public void verify_user_should_able_to_accept_the_payload() {
		
		
		
	}
	@Given("Verify user should able to text the phone number")
	public void verify_user_should_able_to_text_the_phone_number() {
		
		
		
	}
	@Given("Verify user should not able to take invalid phone number")
	public void verify_user_should_not_able_to_take_invalid_phone_number() {
		
		
		
	}
	@Then("Verify place_id is generated")
	public void verify_place_id_is_generated() {
		
		
		
	}
	@Then("Verify status is {string}")
	public void verify_status_is(String string) {
		
		
		
	}
	@Given("Verify whether its accepting location key and value")
	public void verify_whether_its_accepting_location_key_and_value() {
		
		
		
	}

}