package apiEngine;

public class Route {

    private static final String BOOKSTORE = "/BookStore";
    private static final String ACCOUNT = "/Account";
    private static final String VERSION = "/v1";
    
    
    public static String generateToken(){
    	return ACCOUNT + VERSION + "/GenerateToken";
    }

    public static String books(){ 
    	return BOOKSTORE + VERSION + "/Books";
    }

    public static String book(){ 
    	return BOOKSTORE + VERSION + "/Book";
    }

    public static String userAccount(String userId){
    	return ACCOUNT + VERSION + "/User" + "/" + userId; 
    }

    
    
    private static final String MAPS = "/maps";
    private static final String API = "/api";
    private static final String PLACE = "/place";
    private static final String JSON = "/json";
    
    
    public static String post(){
    	return MAPS + API + PLACE + "/post" + JSON +"?key=qaclick123";
    }

    public static String get(String place_id){ 
    	return MAPS + API + PLACE + "/get" + JSON +"?key=qaclick123"+ "/place_id" + "/" + place_id;
    }

    public static String put(String place_id){ 
    	return MAPS + API + PLACE + "/put" + JSON +"?key=qaclick123"+ "/place_id" + "/" + place_id;
    }

    public static String delete(String place_id){
    	return MAPS + API + PLACE + "/delete" + JSON +"?key=qaclick123&" + "/place_id" + "/" + place_id; 
    }
    
    
}