package stepDefinitions;

import apiEngine.EndPoints;
import io.cucumber.java.en.*;

public class maps {


	EndPoints endpoint;
	@Given("Verify user should able to access the {string}")
	public void verify_user_should_able_to_access_the(String string) {
		endpoint =  new EndPoints(string);
	}
	@Given("Verify user should not able to access the {string}")
	public void verify_user_should_not_able_to_access_the(String string) {
		EndPoints endpoint1 =  new EndPoints(string);
	}
	@When("Verify user should able to access {string} Method")
	public void verify_user_should_able_to_access_method(String string) {
	}
	@When("Verify user should not be able to access {string} Method")
	public void verify_user_should_not_be_able_to_access_method(String string) {
	}
	@Then("Verify status is {string}")
	public void verify_status_is(String string) {
	}



}
