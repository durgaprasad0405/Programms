package apiEngine.model.responses;

import java.util.List;
import apiEngine.model.Book;

public class Books {

	public static Object[] isbn;
	public List<Book> books;
}
