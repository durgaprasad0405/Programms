package testScripts;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;

import functionalLib.BusinessActions;
import static io.restassured.RestAssured.*;
import io.restassured.response.Response;
import utilities.CommonUtilities;
import utilities.ExcelOps;
import utilities.Global;
import utilities.Report;
import utilities.RestServices;

public class PostPetFormData extends Global {

	ExcelOps excelOps = new ExcelOps();
	BusinessActions businessActions = new BusinessActions();
	RestServices restServices = new RestServices();
	CommonUtilities commonUtils = new CommonUtilities();
	// DataBaseOps dbOps = new DataBaseOps();
	Report report = new Report();
	ResultSet rs = null;
	Date systemDate = new Date();

	public PostPetFormData() throws FileNotFoundException, IOException, ParseException {
		logger.info("Entered in to " + serviceName + " method.");
		String id = null;
		Response response = null;
		String baseURI, contentType, userName, password, inputPayload;
		String executionFlag = null, actResponseCode = "", excelFileName="", sheetName="", testCaseNum="";
		String dbErrorCode = null, dbErrorMessage = null;
		String[] resultSheetHeaders = null;
		long responseTime = 0;
		int rowNum, rn, cn;
		HashMap<String, Object> jsonResultMap;

		workbook = excelOps.excelFileRead(inputTestDataFolder + environment + "/" + testScriptFile);
		baseURI = commonUtils.getProperties(environment + ".endpointUrl");
		contentType = commonUtils.getProperties(environment + ".contentType");
		userName = commonUtils.getProperties(environment + ".ddi_username");
		password = commonUtils.getProperties(environment + ".ddi_password");
		
		

		try {
			resultSheetHeaders = commonUtils.getProperties("ddiHeaders").split(",");
			resultSheetHeaders = commonUtils.appendStringToStringArray(resultSheetHeaders,
					"teleWCDDIHIST Response Time (sec)");
			resultSheetHeaders = commonUtils.appendStringToStringArray(resultSheetHeaders,
					"teleServiceUsageDataService Response Time (sec)");

			excelOps.createRow(resultFile, serviceName, 0, resultSheetHeaders);
		} catch (Exception e1) {
			logger.error("Error in " + serviceName + " method: " + e1.getMessage());
			logger.error("Trace: " + e1);
		}

		for (rowNum = 1; rowNum <= tdSheet.getLastRowNum(); rowNum++) {
			logger.info("Execution started for TestCase No:" + rowNum);
			executionFlag = excelOps.getCellData(tdSheet, rowNum, "ExecutionFlag");

			if ("Yes".equalsIgnoreCase(executionFlag)) {
				try {

					inputPayloadElementsMap = excelOps.getTestData(tdSheet, rowNum, inputPayloadElementsMap);
					inputPayload = businessActions.generateInputPayload(rowNum, templateName);
					System.out.println(inputPayload);

					resourcePath = resourcePath + "/" + inputPayloadElementsMap.get("payload_petId");
					String data1 = inputPayloadElementsMap.get("payload_data1");
					String name1 = inputPayloadElementsMap.get("payload_name1");
					String data2 = inputPayloadElementsMap.get("payload_data2");
					String name2 = inputPayloadElementsMap.get("payload_name2");
							
					response = restServices.postMethodformData(baseURI, resourcePath, contentType, data1, name1,
							data2, name2);
					
					responseTime = restServices.responseTime(response);

					String resp = response.asString();
					actResponseCode = String.valueOf(response.getStatusCode());
					restServices.responseCodeValidation(response);
					
//					jsonResultMap = commonUtils.jsonTOMap(resp);
//					id = jsonResultMap.get("id").toString();
//					System.out.println(id);
					

					
				} catch (Exception e) {
					failureReason += "Exception in " + serviceName + " service. Reason:- " + e.getMessage();
					logger.error("Exception in " + serviceName + " service. Reason:- " + e);
				}
				if (!failureReason.isEmpty()) {
					resultSheetHeaders = new String[] { String.valueOf(rowNum), inputPayloadElementsMap.get("TestCase"),
							inputPayloadElementsMap.get(expectedHttpResponseCode), actResponseCode,
							String.valueOf(responseTime), dbErrorCode, dbErrorMessage, "FAIL", failureReason };
					excelOps.createRow(resultFile, serviceName, rowNum, resultSheetHeaders);
					report.failTest(inputPayloadElementsMap.get("TestCase"), failureReason);
					logger.info("Execution status of Test Case number: '" + rowNum + "' is : FAIL. Failure reason is: "
							+ failureReason);
					failureReason = "";
				} else {
					resultSheetHeaders = new String[] { String.valueOf(rowNum), inputPayloadElementsMap.get("TestCase"),
							inputPayloadElementsMap.get(expectedHttpResponseCode), actResponseCode,
							String.valueOf(responseTime), dbErrorCode, dbErrorMessage, "PASS", failureReason };
					excelOps.createRow(resultFile, serviceName, rowNum, resultSheetHeaders);
					report.passTest(inputPayloadElementsMap.get("TestCase"));
					logger.info("Execution status of Test Case number: '" + rowNum + "' is : PASS ");
				}

			} else {
				resultSheetHeaders = new String[] { String.valueOf(rowNum),
						excelOps.getCellData(tdSheet, rowNum, "TestCase"), "", "", "", dbErrorCode, dbErrorMessage,
						"Not Executed", failureReason };
				excelOps.createRow(resultFile, serviceName, rowNum, resultSheetHeaders);
				// report.skipTest(excelOps.getCellData(rowNum, "TestCase"));
				logger.info("Execution status of Test Case number: '" + rowNum + "' is : Execution Not required ");
			}
		}

		logger.info("Exit from " + serviceName + " method.");
  
	}
}