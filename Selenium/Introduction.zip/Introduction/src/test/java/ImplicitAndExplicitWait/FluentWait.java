package ImplicitAndExplicitWait;

public class FluentWait {
	public static void main(String[] args) {
		
		
	}

}
