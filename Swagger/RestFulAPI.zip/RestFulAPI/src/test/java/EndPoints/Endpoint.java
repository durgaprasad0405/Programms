package EndPoints;

public class Endpoint {
	
	//BookStore Base URL		//https://bookstore.toolsqa.com
	public static String Base_url = "https://api.restful-api.dev";
	
	//Account EndPoints
	public static String post_Object = Base_url+"/objects";
	public static String put_Object = Base_url+"/objects/";
	public static String get_Object = Base_url+"/objects/";
	public static String delete_Object = Base_url+"/objects/";


}
